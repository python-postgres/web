#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.15 2008/05/30 02:48:49 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
import sys
import os
NAME = 'greentrunk'
VERSION = '1.0'

LONG_DESCRIPTION = """
GreenTrunk is an Interface Protocol(API) for using a PostgreSQL database
with Python. This project provides fundamental components of the
interface for implementations to use, and provides documentation in the form of
Python modules to allow immediate access to object descriptions--even when
inside a Python console.
"""

classifiers = [
	'Development Status :: 5 - Production/Stable',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' : 'GreenTrunk interface support',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'classifiers' : classifiers,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
	'install_requires' : [
		'jwp_python_command >= 1.1',
		'pg_foundation >= 1.0',
	],
	'namespace_packages' : [
		'postgresql',
		'postgresql.protocol',
	],
	'packages' : [
		'postgresql',
		'postgresql.protocol',
		'postgresql.protocol.greentrunk',
		'postgresql.protocol.greentrunk.test',
	],
	'entry_points' : {
		'console_scripts' : [
			'pg_greentrunk = postgresql.protocol.greentrunk:connection_api_ep'
		]
	},
}

# Conditionally provide pkg_documentation keys.
try:
	import pkg_resources as pr
	try:
		pr.require('jwp_pkg_documentation')
		defaults['doc_ignore'] = [
			'postgresql.protocol.greentrunk.test.'
		]
	except pr.DistributionNotFound:
		pass
except ImportError:
	pass

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
