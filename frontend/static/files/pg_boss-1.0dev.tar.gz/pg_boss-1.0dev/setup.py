#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.10 2008/05/30 02:56:30 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
import sys
import os

NAME = 'boss'
VERSION = '1.0dev'

LONG_DESCRIPTION = """
The boss project provides functionality for managing PostgreSQL database
clusters. Initialization, configuration, and execution are covered by three
seperate modules in the package.

The 'init' module provides a Python interface to database cluster initialization,
initdb. It provides the means to do so with many options.

The 'config' module provides a Python interface to a cluster's configuration,
postgresql.conf. It provides a basic mechanism to parse setting lines in the
files and a relatively intelligent mechanism for applying configuration
alterations.

The 'hba' module provides a Python interface to a cluster's HBA file,
pg_hba.conf. It provides basic methods for parsing, and altering of HBA lines.

The 'control' module provides a Python interface to controlling the Postgres
process, via pg_ctl.
"""

classifiers = [
	'Development Status :: 4 - Beta',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' : 'Create, configure, and control PostgreSQL clusters in Python',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'classifiers' : classifiers,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'zip_safe' : True,
	'namespace_packages' : [
		'postgresql',
		'postgresql.backend',
	],
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
	'packages' : [
		'postgresql',
		'postgresql.backend',
		'postgresql.backend.boss',
	],
	'entry_points' : {
		'console_scripts' : [
			'pg_dotconf = postgresql.backend.boss.config:main',
			'pg_hba = postgresql.backend.boss.hba:main',
		],
	},
}

# Conditionally provide pkg_documentation keys.
try:
	import pkg_resources as pr
	try:
		pr.require('jwp_pkg_documentation')
		defaults['doc_ignore'] = [
			'postgresql.backend.boss.test',
		]
	except pr.DistributionNotFound:
		pass
except ImportError:
	pass

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
