# -*- encoding: utf-8 -*-
# $Id: init.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
'PostgreSQL catalog cluster initialization interfaces'
import sys
import os
import subprocess as sp
import signal

class InitializorError(Exception):
	pass

class Initializor(object):
	'Base initializor'

	def __repr__(self):
		return '%s.%s(%r)' %(
			self.__module__,
			type(self).__name__,
			self._path,
		)

	def __init__(self, path = 'initdb'):
		self._path = path

class initdb(Initializor):
	'initdb based initializor'

	_options = {
		'encoding' : '-E',
		'locale' : '--locale',
		'collate' : '--lc-collate',
		'ctype' : '--lc-ctype',
		'monetary' : '--lc-monetary',
		'numeric' : '--lc-numeric',
		'time' : '--lc-time',
		'authentication' : '-A',
		'superusername' : '-U',
		'superuserpass' : '--pwfile',
		'verbose' : '-d',
		'sources' : '-L',
	}

	def sources(self, datadir = None):
		p = sp.Popen(
			(self._path, '-s') + \
			datadir is not None and ('-D', datadir, '-s') or (),
			stdin = sp.PIPE,
			stdout = sp.PIPE,
			stderr = sp.STDOUT
		)
		p.stdin.close()

		try:
			rc = p.wait()
		except KeyboardInterrupt:
			os.kill(p.pid, signal.SIGTERM)
			raise

		if rc != 0:
			raise InitializorError, (rc, p.stdout.read())
		return p.stdout.read()

	def __call__(self, datadir, **kw):
		opts = []
		for x in kw:
			if x in ('nowait', 'logfile', 'extra_arguments'):
				continue
			if x not in self._options:
				raise TypeError, "got an unexpected keyword argument %r" %(x,)
			opts.append(self._options[x])
			opts.append(kw[x])
		nowait = kw.get('nowait', False)
		logfile = kw.get('logfile', sp.PIPE)
		extra_args = kw.get('extra_arguments', ())

		p = sp.Popen(
			(self._path, '-D', datadir) + tuple(opts) + extra_args,
			close_fds = True,
			stdin = sp.PIPE,
			stdout = logfile,
			stderr = sp.PIPE
		)
		p.stdin.close()

		if nowait:
			return p

		try:
			rc = p.wait()
		except KeyboardInterrupt:
			os.kill(p.pid, signal.SIGTERM)
			raise

		if rc != 0:
			raise InitializorError, (rc, p.stderr.read())
Initialize = initdb
