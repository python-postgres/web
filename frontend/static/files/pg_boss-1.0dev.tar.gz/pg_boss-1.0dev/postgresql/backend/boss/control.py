# -*- encoding: utf-8 -*-
# $Id: control.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
import sys
import os
import signal
import subprocess as sp
import warnings

class ControlWarning(UserWarning):
	pass
class ControlError(Exception):
	pass

class Controller(object):
	'Abstract Controller'
	pass

class pg_ctl(Controller):
	'Python interface to a pg_ctl command relative to a data directory'

	def __init__(self, location, pg_ctl_path = 'pg_ctl'):
		"""
		Takes the data directory path and the pg_ctl command's path,
		"""
		self._pg_ctl = pg_ctl_path
		self.data = os.path.realpath(location)
		if not os.path.isdir(location):
			warnings.warn("data directory %r does not exist" %(location,),
				ControlWarning)
		self._subproc_prefix = (pg_ctl_path, '-D', location,)

	def __repr__(self):
		return '%s.%s(%r, %r)' %(
			self.__module__,
			type(self).__name__,
			self.data, self._pg_ctl
		)

	def start(self, postmaster = None, options = None,
		nowait = False, logfile = None
	):
		"""
		Start the cluster with the given parameters.
		"""
		rest = ['-s', '-w', 'start']
		if postmaster is not None:
			rest.insert(0, str(postmaster))
			rest.insert(0, '-p')
		if options is not None:
			rest.append('-o')
			rest.append(' '.join([str(x) for x in options]))

		p = sp.Popen(
			self._subproc_prefix + tuple(rest),
			stdin = sp.PIPE,
			stdout = (logfile is None and sp.PIPE or logfile),
			stderr = sp.STDOUT
		)
		p.stdin.close()

		if nowait:
			return p

		try:
			rc = p.wait()
		except KeyboardInterrupt:
			os.kill(p.pid, signal.SIGTERM)
			raise

		if logfile is None:
			out = os.read(p.stdout.fileno(), 2048)
		else:
			out = 'non-zero result or was not running'
		if rc != 0 or not self.running():
			raise ControlError((rc, out))
		return out

	def restart(self, postmaster = None, options = None,
			mode = 'smart', nowait = False, logfile = None
		):
		"""
		Restart the cluster
		"""
		rest = ['-m', mode, '-s', '-w', 'restart']
		if postmaster is not None:
			rest.insert(0, str(postmaster))
			rest.insert(0, '-p')
		if options is not None:
			rest.append('-o')
			rest.append(' '.join([str(x) for x in options]))

		p = sp.Popen(
			self._subproc_prefix + tuple(rest),
			stdin = sp.PIPE,
			stdout = (logfile is None and sp.PIPE or logfile),
			stderr = sp.STDOUT
		)
		p.stdin.close()

		if nowait:
			return p

		try:
			rc = p.wait()
		except KeyboardInterrupt:
			os.kill(p.pid, signal.SIGTERM)
			raise

		if logfile is None:
			out = os.read(p.stdout.fileno(), 2048)
		else:
			out = 'non-zero result or was not running'
		if rc != 0 or not self.running():
			raise ControlError((rc, out))
		return out

	def running(self):
		"""
		Check whether the cluster is running.
		"""
		p = sp.Popen(
			self._subproc_prefix + ('status',),
			stdin = sp.PIPE, stdout = sp.PIPE, stderr = sp.STDOUT
		)
		p.stdin.close()
		p.stdout.close()
		return (p.wait() == 0)

	def stop(self, mode = 'smart', nowait = False):
		"""
		Stop the running cluster
		"""
		p = sp.Popen(
			self._subproc_prefix + (
				nowait and '-W' or '-w',
				'-s', '-m', mode, 'stop',
			),
			stdin = sp.PIPE,
			stdout = sp.PIPE,
			stderr = sp.STDOUT
		)
		p.stdin.close()

		if nowait:
			return p

		try:
			rc = p.wait()
		except KeyboardInterrupt:
			os.kill(p.pid, signal.SIGTERM)
			raise

		if rc != 0:
			raise ControlError((rc, os.read(p.stdout.fileno(), 512)))
		return os.read(p.stdout.fileno(), 256)

	def reload(self):
		"""
		Reload the cluster--graceful restart.
		"""
		p = sp.Popen(
			self._subproc_prefix + ('-s', 'reload',),
			stdin = sp.PIPE,
			stdout = sp.PIPE,
			stderr = sp.STDOUT
		)
		p.stdin.close()

		try:
			rc = p.wait()
		except KeyboardInterrupt:
			os.kill(p.pid, signal.SIGTERM)
			raise

		out = p.stdout.read()
		if rc != 0:
			raise ControlError((rc, out))
		return out
Control = pg_ctl
##
# vim: ts=3:sw=3:noet:
