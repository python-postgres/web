# -*- encoding: utf-8 -*-
# $Id: cluster.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
'PostgreSQL cluster management interfaces'
import os
import postgresql.backend.boss.config as pgsql_conf
from postgresql.backend.boss.init import Initialize as pg_init
from postgresql.backend.boss.control import Control as pg_control

DEFAULT_CONFIG_FILENAME = 'postgresql.conf'
DEFAULT_HBA_FILENAME = 'pg_hba.conf'

class Cluster(object):
	"Cluster management class"

	def create(subtype, cluster_path, pg_config_dict, **kw):
		'Create a cluster at the given cluster path with the given pg_config'
		initdb = pg_init(os.path.join(pg_config_dict['bindir'], 'initdb'))
		initdb(cluster_path, **kw)
		return subtype(cluster_path, pg_config_dict)
	create = classmethod(create)

	def __repr__(self):
		return "%s.%s(%r, %r)" %(
			type(self).__module__,
			type(self).__name__,
			self.control.data,
			self.pg_config_path
		)

	def __init__(self, cluster_path, pg_config_dict):
		self.control = pg_control(cluster_path, os.path.join(pg_config_dict['bindir'], 'pg_ctl'))
		self.config = pg_config_dict
		self.pgsql_dot_conf = os.path.join(cluster_path, DEFAULT_CONFIG_FILENAME)
		self.pghba_dot_conf = os.path.join(cluster_path, DEFAULT_HBA_FILENAME)

	def drop(self):
		'Stop the cluster and delete it from the filesystem'
		if self.control.running():
			self.control.stop()
		# Really, using rm -rf would be the best, but use this for portability.
		for root, dirs, files in os.walk(self.control.data, topdown = False):
			for name in files:
				os.remove(os.path.join(root, name))
			for name in dirs:
				os.rmdir(os.path.join(root, name))	
		os.rmdir(self.control.data)

	def set_parameters(self, keyvals):
		"""
		Given a dictionary of settings, apply them to the cluster's
		postgresql.conf.
		"""
		cf = open(self.pgsql_dot_conf)
		try:
			lines = pgsql_conf.alter_config(keyvals, cf)
		finally:
			cf.close()
		cf = open(self.pgsql_dot_conf, 'w')
		try:
			for l in lines:
				cf.write(l)
		finally:
			cf.close()

	def get_parameters(self, keys):
		"""
		Get all the settings requested in the list of keys

		Returns a dictionary of those keys with the values stored in the
		configuration file.
		"""
		return self.select_parameters(lambda x: (x in keys))

	def select_parameters(self, selector):
		"""
		Get all the settings that the given selector chooses.

		Returns a dictionary of those keys 
		"""
		return pgsql_conf.read_config(
			open(self.pgsql_dot_conf), selector = selector
		)
