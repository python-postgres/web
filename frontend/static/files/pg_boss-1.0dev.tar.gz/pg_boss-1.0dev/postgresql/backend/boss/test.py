# -*- encoding: utf-8 -*-
# $Id: test.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
# copyright 2008, pg/python project.
# http://python.projects.postgresql.org
##
import sys
import os
import unittest
from postgresql.backend.boss.cluster import Cluster as pg_cluster

class test_cluster(unittest.TestCase):
	def setUp(self):
		pg_config_path = os.environ.get("PGCONFIG", "pg_config")
		pg_data_path = os.environ.get(
			"PGTESTDATA", os.path.realpath("tempdatdir")
		)
		sys.stderr.write('Initializing cluster[%s:%s]..' %(
				pg_config_path,
				pg_data_path
			)
		)
		self.cluster = pg_cluster.create(pg_data_path, pg_config_path)
		sys.stderr.write('done!\n')

	def tearDown(self):
		self.cluster.drop()
		self.cluster = None

	def testInterface(self, inside = False):
		self.failUnless(hasattr(self.cluster, 'control'))
		self.failUnless(hasattr(self.cluster, 'config'))
		self.failUnless(hasattr(self.cluster, 'pg_config_path'))
		self.failUnless(hasattr(self.cluster, 'pgsql_dot_conf'))
		self.failUnless(hasattr(self.cluster, 'pghba_dot_conf'))
		port = 7654
		self.cluster.set_parameters({
			'port' : str(port)
		})
		# Fetch port using the 'keys' keyword
		self.failUnless(
			self.cluster.get_parameters(('port',))['port'] == str(port)
		)
		# Fetch port using the selector keyword
		self.failUnless(
			self.cluster.get_parameters(
				selector = (lambda x: x == 'port')
			)['port'] == str(port)
		)
		# Fetch all parameters
		self.failUnless(
			self.cluster.get_parameters()['port'] == str(port)
		)
		self.failIf(self.cluster.control.running())
		self.cluster.control.start()
		self.failIf(not self.cluster.control.running())
		self.cluster.control.stop()
		self.failIf(self.cluster.control.running())
		if not inside:
			c = self.cluster
			self.cluster = pg_cluster(c.control.data, c.pg_config_path)
			self.testInterface(inside = True)
			self.cluster = c
# cluster

try:
	from cStringIO import StringIO
except ImportError:
	from StringIO import StringIO
import postgresql.backend.boss.config as cfg

sample_config_Aroma = \
"""
##
# A sample config file.
##
# This provides a good = test for alter_config.

#shared_buffers = 4500
search_path = window,$user,public
shared_buffers = 2500

port = 5234
listen_addresses = 'localhost'
listen_addresses = '*'
"""

##
# Wining cases are alteration cases that provide
# source and expectations from an alteration.
#
# The first string is the source, the second the
# alterations to make, the and the third, the expectation.
##
winning_cases = [
	(
		# Two top contenders
		"foo = bar\nfoo = bar",
		{'foo' : 'newbar'},
		"foo = newbar\n#foo = bar"
	),
	(
		# Two top contenders, first one commented
		"#foo = bar\nfoo = bar",
		{'foo' : 'newbar'},
		"#foo = bar\nfoo = newbar"
	),
	(
		# Two top contenders, second one commented
		"foo = bar\n#foo = bar",
		{'foo' : 'newbar'},
		"foo = newbar\n#foo = bar"
	),
	(
		# Two candidates
		"foo = bar\nfoo = none",
		{'foo' : 'bar'},
		"foo = bar\n#foo = none"
	),
	(
		# Two candidates, winner should be the first, second gets comment
		"#foo = none\nfoo = bar",
		{'foo' : 'none'},
		"foo = none\n#foo = bar"
	),
	(
		# Two commented candidates
		"#foo = none\n#foo = some",
		{'foo' : 'bar'},
		"foo = bar\n#foo = some"
	),
	(
		# Two commented candidates, the latter a top contender
		"#foo = none\n#foo = bar",
		{'foo' : 'bar'},
		"#foo = none\nfoo = bar"
	),
	(
		# Replace empty value
		"foo = \n",
		{'foo' : 'feh'},
		"foo = feh"
	),
	(
		# Comment value
		"foo = bar",
		{'foo' : None},
		"#foo = bar"
	),
	(
		# Commenting after value
		"foo = val this should be commented",
		{'foo' : 'newval'},
		"foo = newval #this should be commented"
	),
	(
		# Commenting after value
		"#foo = val this should be commented",
		{'foo' : 'newval'},
		"foo = newval #this should be commented"
	),
	(
		# Commenting after quoted value
		"#foo = 'val'foo this should be commented",
		{'foo' : 'newval'},
		"foo = newval #this should be commented"
	),
	(
		# Adjacent post-value comment
		"#foo = 'val'#foo this should be commented",
		{'foo' : 'newval'},
		"foo = newval#foo this should be commented"
	),
]

class test_config(unittest.TestCase):
	def parseNone(self, line):
		sl = cfg.parse_line(line)
		if sl is not None:
			self.fail(
				"With line %r, parsed out to %r, %r, and %r, %r, " \
				"but expected None to be returned by parse function." %(
					line, line[sl[0]], sl[0], line[sl[0]], sl[0]
				)
			)

	def parseExpect(self, line, key, val):
		line = line %(key, val)
		sl = cfg.parse_line(line)
		if sl is None:
			self.fail(
				"expecting %r and %r from line %r, " \
				"but got None(syntax error) instead." %(
					key, val, line
				)
			)
		k, v = sl
		if line[k] != key:
			self.fail(
				"expecting key %r for line %r, " \
				"but got %r from %r instead." %(
					key, line, line[k], k
				)
			)
		if line[v] != val:
			self.fail(
				"expecting value %r for line %r, " \
				"but got %r from %r instead." %(
					val, line, line[v], v
				)
			)

	def testParser(self):
		self.parseExpect("#%s = %s", 'foo', 'none')
		self.parseExpect("#%s=%s\n", 'foo', 'bar')
		self.parseExpect(" #%s=%s\n", 'foo', 'bar')
		self.parseExpect('%s =%s\n', 'foo', 'bar')
		self.parseExpect(' %s=%s \n', 'foo', 'Bar')
		self.parseExpect(' %s = %s \n', 'foo', 'Bar')
		self.parseExpect('# %s = %s \n', 'foo', 'Bar')
		self.parseExpect('\t # %s = %s \n', 'foo', 'Bar')
		self.parseExpect('  # %s =   %s \n', 'foo', 'Bar')
		self.parseExpect("  # %s = %s\n", 'foo', "' Bar '")
		self.parseExpect("%s = %s# comment\n", 'foo', '')
		self.parseExpect("  # %s = %s # A # comment\n", 'foo', "' B''a#r '")
		# No equality or equality in complex comment
		self.parseNone(' #i  # foo =   Bar \n')
		self.parseNone('#bar')
		self.parseNone('bar')

	def testConfigRead(self):
		sample = "foo = bar\n# A comment, yes.\n bar = foo # yet?\n"
		d = cfg.read_config(sample.split('\n'))
		self.failUnless(d['foo'] == 'bar')
		self.failUnless(d['bar'] == 'foo')

	def testConfigWriteRead(self):
		strio = StringIO()
		d = {
			'' : "'foo bar'"
		}
		cfg.write_config(d, strio.write)
		strio.seek(0)

	def testWinningCases(self):
		i = 0
		for before, alters, after in winning_cases:
			befg = (x + '\n' for x in before.split('\n'))
			became = ''.join(cfg.alter_config(alters, befg))
			self.failUnless(
				became.strip() == after,
				'On %d, before, %r, did not become after, %r; got %r using %r' %(
					i, before, after, became, alters
				)
			)
			i += 1

	def testSimpleConfigAlter(self):
		# Simple set and uncomment and set test.
		strio = StringIO()
		strio.write("foo = bar\n # bleh = unset\n # grr = 'oh yeah''s'")
		strio.seek(0)
		lines = cfg.alter_config({'foo' : 'yes', 'bleh' : 'feh'}, strio)
		d = cfg.read_config(lines)
		self.failUnless(d['foo'] == 'yes')
		self.failUnless(d['bleh'] == 'feh')
		self.failUnless(''.join(lines).count('bleh') == 1)

	def testAroma(self):
		lines = cfg.alter_config({
				'shared_buffers' : '800',
				'port' : None
			}, (x + '\n' for x in sample_config_Aroma.split('\n'))
		)
		d = cfg.read_config(lines)
		self.failUnless(d['shared_buffers'] == '800')
		self.failUnless(d.get('port') is None)

		nlines = cfg.alter_config({
				'port' : '1'
			}, lines
		)
		d2 = cfg.read_config(nlines)
		self.failUnless(d2.get('port') == '1')
		self.failUnless(
			nlines[:4] == lines[:4]
		)
	
	def testSelection(self):
		# Sanity
		red = cfg.read_config(['foo = bar\n', 'bar = foo'])
		self.failUnless(len(red.keys()) == 2)

		# Test a simple selector
		red = cfg.read_config(['foo = bar\n', 'bar = foo'],
			selector = lambda x: x == 'bar')
		rkeys = red.keys()
		self.failUnless(len(rkeys) == 1)
		self.failUnless(rkeys[0] == 'bar')
		self.failUnless(red['bar'] == 'foo')

from postgresql.backend.boss.init import Initialize as initdb
from postgresql.backend.boss.control import Control as pg_ctl
import postgresql.interface.proboscis.greentrunk as gt

class test_control(unittest.TestCase):
	def testMeth(self):
		pgcfg_path = os.environ.get("PGCONFIG", "pg_config")
		pgctl_path = os.environ.get("PGCONTROL", "pg_ctl")
		initdb_path = os.environ.get("PGINITDB", "initdb")

		datdir = os.environ.get("PGTESTDATA", os.path.realpath('tempdatdir'))
		i = initdb(initdb_path)
		i(datdir, logfile = sys.stderr)
		port = 10001
		cnctr = gt.Connector(
			user = os.getlogin(),
			host = 'localhost',
			port = port,
			database = 'template1'
		)

		if not os.path.isdir(datdir):
			self.fail("failed to initialize database directory %r" %(datdir,))

		cf = open(os.path.join(datdir, 'postgresql.conf'), 'w')
		cf.write(
			'max_connections = 10\nlisten_addresses = localhost\nport = %d' %(
				port,
			)
		)
		cf.close()

		try:
			c = pg_ctl(datdir, pgctl_path)
			c.start(logfile = sys.stderr)
			try:
				C = cnctr()
				try:
					self.failUnless(
						C.Query("SELECT 1")().next()[0] == 1
					)
					self.failUnless(c.running(),
						"server is not running, " \
						"yet there is an open connection to it")
				finally:
					C.close()
			finally:
				c.stop(mode = 'fast')

			c.start(logfile = sys.stderr)
			try:
				C = cnctr()
				try:
					c.reload()
					self.failUnless(
						C.Query("SELECT 1")().next()[0] == 1
					)
				finally:
					C.close()
				c.restart(logfile = sys.stderr)
				C = cnctr()
				try:
					self.failUnless(
						C.Query("SELECT 1")().next()[0] == 1
					)
				finally:
					C.close()
			finally:
				c.stop()
		finally:
			pass
			# Remove DB directory
# pg_ctl

import postgresql.backend.boss.hba as hba

class hba_case(unittest.TestCase):
	def parseNone(self, line):
		sl = hba.parse_line(line)
		if sl is not None:
			self.fail(
				"With line %r, parsed out to %r(%r), " \
				"but expected None to be returned by parse function." %(
					line, sl, [line[x] for x in sl]
				)
			)

	def parseExpect(self, line, fields):
		for x in fields:
			self.failIf(' ' in x, 'bad field')
			self.failIf('\t' in x, 'bad field')
			self.failIf('#' in x, 'bad field')
		line = line % fields
		fslices = hba.parse_line(line)
		if fslices is None:
			self.fail(
				"expecting %r and %r from line %r, " \
				"but got None(syntax error) instead." %(
					key, val, line
				)
			)
		for x in xrange(len(fields)):
			if line[fslices[x]] != fields[x]:
				self.fail(
					"expecting %r in field %d for line %r, " \
					"but got %r instead." %(
						fields[x], x, line, line[fslices[x]]
					)
				)

	def testParser(self):
		self.parseNone('')
		self.parseNone(' ')
		self.parseNone('  # foo')
		self.parseNone('\t        \n')
		self.parseNone('##bar')
		self.parseNone('#  # foo bar')
		self.parseNone('#foo bar bleh ####')
		self.parseNone('#Too many fields to consider it an entry')
		self.parseNone('#Too few # fields to consider')
		self.parseExpect('%s %s %s %s', ('local', 'all', 'all', 'trust'))
		self.parseExpect('%s %s %s %s %s', (
			'host', 'all', 'all', '127.0.0.1/32', 'trust'
		))
		self.parseExpect('%s %s %s %s %s %s', (
			'host', 'all', 'all', '127.0.0.1/32', 'trust', 'options'
		))
		self.parseExpect('%s %s %s %s', ('local', 'all', 'all', 'trust'))
		self.parseExpect(' %s %s %s %s', ('local', 'all', 'all', 'trust'))
		self.parseExpect('  %s %s %s %s', ('local', 'all', 'all', 'trust'))
		self.parseExpect('  %s %s %s %s  #foo', ('local', 'all', 'all', 'trust'))
		self.parseExpect('  %s %s %s %s#foo', ('local', 'all', 'all', 'trust'))
		self.parseExpect('  %s %s %s %s #foo', ('local', 'all', 'all', 'trust'))
		self.parseExpect('  %s %s %s %s %s #foo', (
			'hostssl', 'jwp', 'all', '192.186.1.1/32', 'md5'
		))
	
	def testInterface(self):
		si = hba.Sequence([
			'## Some leading commentary\n',
			'# Some more leading commentary\n',
			'local \tall \tall reject\n',
			'# some comment\n',
			'host all all 127.0.0.1/32 trust\n',
			'host all all 172.16.1.1/32 trust\n',
		])
		si_len = len(si)
		self.failUnless(si_len == 3)

		self.failUnless(si[0] == ('local', 'all', 'all', 'reject',))
		self.failUnless(si[1] == ('host', 'all', 'all', '127.0.0.1/32', 'trust',))
		self.failUnless(si[2] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',))
		si.insert_before(
			('local', 'all', 'all', 'reject',),
			('local', 'all', 'all', 'trust',),
		)
		si_len += 1
		self.failUnless(len(si) == si_len)
		self.failUnless(si[0] == ('local', 'all', 'all', 'trust',))
		self.failUnless(si[1] == ('local', 'all', 'all', 'reject',))
		self.failUnless(si[2] == ('host', 'all', 'all', '127.0.0.1/32', 'trust',))
		self.failUnless(si[3] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',))
		si.insert_after(
			('host', 'all', 'all', '172.16.1.1/32', 'trust'),
			('host', 'jwp', 'jwp', '172.16.1.1/32', 'reject'),
		)
		si_len += 1
		self.failUnless(len(si) == si_len)
		self.failUnless(si[0] == ('local', 'all', 'all', 'trust',))
		self.failUnless(si[1] == ('local', 'all', 'all', 'reject',))
		self.failUnless(si[2] == ('host', 'all', 'all', '127.0.0.1/32', 'trust',))
		self.failUnless(
			si[3] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',)
		)
		self.failUnless(
			si[4] == ('host', 'jwp', 'jwp', '172.16.1.1/32', 'reject',)
		)
		si.append(('hostssl', 'pgsql', 'pgsql', '192.168.1.5', 'md5'),)
		si_len += 1
		self.failUnless(len(si) == si_len)
		self.failUnless(si[0] == ('local', 'all', 'all', 'trust',))
		self.failUnless(si[1] == ('local', 'all', 'all', 'reject',))
		self.failUnless(si[2] == ('host', 'all', 'all', '127.0.0.1/32', 'trust',))
		self.failUnless(
			si[3] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',)
		)
		self.failUnless(
			si[4] == ('host', 'jwp', 'jwp', '172.16.1.1/32', 'reject',)
		)
		self.failUnless(
			si[5] == ('hostssl', 'pgsql', 'pgsql', '192.168.1.5', 'md5',)
		)
		del si[4]
		si_len -= 1
		self.failUnless(len(si) == si_len)
		self.failUnless(si[0] == ('local', 'all', 'all', 'trust',))
		self.failUnless(si[1] == ('local', 'all', 'all', 'reject',))
		self.failUnless(si[2] == ('host', 'all', 'all', '127.0.0.1/32', 'trust',))
		self.failUnless(
			si[3] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',)
		)
		self.failUnless(
			si[4] == ('hostssl', 'pgsql', 'pgsql', '192.168.1.5', 'md5',)
		)

		del si[0:2]
		si_len -= 2
		self.failUnless(len(si) == si_len)
		self.failUnless(si[0] == ('host', 'all', 'all', '127.0.0.1/32', 'trust',))
		self.failUnless(
			si[1] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',)
		)
		self.failUnless(
			si[2] == ('hostssl', 'pgsql', 'pgsql', '192.168.1.5', 'md5',)
		)

		si[0] = None
		si_len -= 1
		self.failUnless(len(si) == si_len)
		self.failUnless(
			si[0] == ('host', 'all', 'all', '172.16.1.1/32', 'trust',)
		)
		self.failUnless(
			si[1] == ('hostssl', 'pgsql', 'pgsql', '192.168.1.5', 'md5',)
		)

		si[0:2] = (
			('host', 'all', 'jwp', '172.16.1.2/32', 'trust',),
			('host', 'all', 'all', '192.168.1.5/32', 'md5',),
		)

		self.failUnless(
			si[0] == ('host', 'all', 'jwp', '172.16.1.2/32', 'trust',)
		)
		self.failUnless(
			si[1] == ('host', 'all', 'all', '192.168.1.5/32', 'md5',),
		)
		self.failUnless(
			tuple(si[0:2]) == (
				('host', 'all', 'jwp', '172.16.1.2/32', 'trust',),
				('host', 'all', 'all', '192.168.1.5/32', 'md5',),
			)
		)

if __name__ == '__main__':
	from types import ModuleType
	this = ModuleType("this")
	this.__dict__.update(globals())
	unittest.main(this)
