# -*- encoding: utf-8 -*-
# $Id: config.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
# Copyright 2006, PostgresPy Project.
# http://python.projects.postgresql.org
##
'PostgreSQL configuration file parser and editor functions.'
import sys
import os

quote = u"'"
comment = u'#'

def parse_line(line, equality = '=', comment = comment, quote = quote):
	keyval = line.split(equality, 1)
	if len(keyval) == 2:
		key, val = keyval

		prekey_len = 0
		for c in key:
			if not c.isspace() and c not in comment:
				break
			prekey_len += 1

		key_len = 0
		for c in key[prekey_len:]:
			if not (c.isalpha() or c.isdigit() or c in u'_'):
				break
			key_len += 1

		# If non-whitespace exists after the key,
		# it's a complex comment, so just bail out.
		if key[prekey_len + key_len:].strip():
			return

		preval_len = 0
		for c in val:
			if not c.isspace() or c in '\n\r':
				break
			preval_len += 1

		inquotes = False
		escaped = False
		val_len = 0
		for i in xrange(preval_len, len(val)):
			c = val[i]
			if c == quote:
				if inquotes is False:
					inquotes = True
				else:
					if escaped is False:
						# Peek ahead to see if it's escaped with another quote
						escaped = (len(val) > i+1 and val[i+1] == quote)
						if escaped is False:
							inquotes = False
					elif escaped is True:
						# It *was* an escaped quote.
						escaped = False
			elif inquotes is False and (c.isspace() or c in comment):
				break
			val_len += 1

		return (
			# The key slice
			slice(prekey_len, key_len + prekey_len),
			# The value slice
			slice(len(key) + 1 + preval_len, len(key) + 1 + preval_len + val_len)
		)

def write_config(map, writer, keys = None):
	'A configuration writer that will trample & merely write the settings'
	if keys is None:
		keys = map
	for k in keys:
		writer('='.join((k, map[k])) + os.linesep)

def alter_config(map, fo, keys = None):
	'Alters a configuration file without trampling on the existing structure'
	if keys is None:
		keys = map.keys()
	# Normalize keys and map them back to 
	pkeys = {}
	for k in keys:
		pkeys[k.lower().strip()] = keys.index(k)
	getval_from_pk = lambda k: map[keys[pkeys[k]]]

	lines = []
	candidates = {}
	i = -1
	# Process lines in fo
	for l in fo:
		i += 1
		lines.append(l)
		pl = parse_line(l)
		# "Bad" line? fuh-get-duh-bowt-it.
		if pl is None:
			continue
		sk, sv = pl
		k = l[sk]
		pk = k.lower()
		v = l[sv]
		# It's a candidate
		if k in pkeys:
			c = candidates.get(k)
			if c is None:
				candidates[k] = c = []
			c.append((i, sk, sv))
	# Simply insert the data somewhere for unfound keys.
	for k in pkeys:
		if k not in candidates:
			key = keys[pkeys[k]]
			val = map[key]
			# Can't comment without an uncommented candidate.
			if val is not None:
				# TODO: allow customizable locating
				if not lines[-1].endswith(os.linesep):
					lines[-1] = lines[-1] + os.linesep
				lines.append('%s = %s' %(key, val))

	# Multiple lines may have the key, so make a decision based on the value.
	for ck in candidates.keys():
		to_set_key = keys[pkeys[ck]]
		to_set_val = getval_from_pk(ck)
		if to_set_val is None:
			# Comment uncommented occurrences.
			for cl in candidates[ck]:
				line_num, sk, sv = cl
				if comment not in lines[line_num][:sk.start]:
					lines[line_num] = '#' + lines[line_num]
		else:
			# Manage occurrences.
			# w_ is for winner.
			# Now, a winner is elected for alteration. The winner
			# is decided based on a two factors: commenting and value.
			w_score = -1
			w_commented = None
			w_val = None
			w_cl = None
			for cl in candidates[ck]:
				line_num, sk, sv = cl
				l = lines[line_num]
				lkey = l[sk]
				lval = l[sv]
				commented = (comment in l[:sk.start])
				score = \
					(not commented and 1 or 0) + \
					(lval == to_set_val and 2 or 0)
				# So, if a line is not commented, and has equal
				# values, then that's the winner. If a line is commented,
				# and has a has equal values, it will succeed over a mere
				# uncommented value.

				if score > w_score:
					if w_commented is False:
						# It's now a loser, so comment it out if necessary.
						lines[w_cl[0]] = '#' + lines[w_cl[0]]
					w_score = score
					w_commented = commented
					w_val = lval
					w_cl = cl
				elif commented is False:
					# Loser needs to be commented.
					lines[line_num] = '#' + l

			line_num, sk, sv = w_cl
			l = lines[line_num]
			if w_commented:
				bol = ''
			else:
				bol = l[:sk.start]
			post_val = l[sv.stop:]
			# If there is post-value data, validate that it's commented.
			if post_val and not post_val.isspace():
				stripped_post_val = post_val.lstrip()
				if not stripped_post_val.startswith(comment):
					post_val = '%s%s%s' %(
						# The whitespace before the uncommented visibles
						post_val[0:len(post_val) - len(stripped_post_val)],
						# A comment followed by the uncommented visibles
						comment, stripped_post_val
					)
			lines[line_num] = \
				bol + l[sk.start:sv.start] + to_set_val + post_val
	return lines

def read_config(iter, d = None, selector = None):
	if d is None:
		d = {}
	for line in iter:
		kv = parse_line(line)
		if kv:
			key = line[kv[0]]
			if comment not in line[:kv[0].start] and \
			(selector is None or selector(key)):
				d[key] = line[kv[1]]
	return d

if __name__ == '__main__':
	from optparse import OptionParser
	op = OptionParser(
		"%prog [--stdout] [-f settings] config_file+ param = val+",
		version = '0'
	)
	op.add_option(
		'-f', '--file',
		dest = 'settings',
		help = 'The file of settings to push; parameter arguments may override',
		default = None,
	)
	op.add_option(
		'--stdout',
		dest = 'stdout',
		help = 'Redirect the changed file to standard output',
		action = 'store_true',
		default = False
	)
	co, ca = op.parse_args()
	if not ca:
		sys.exit(0)

	sys.stdin.close()
	sys.stdout.close()

	settings = {}
	if co.settings is not None:
		sf = open(co.settings)
		for line in sf:
			pl = parse_line(line)
			if pl is not None:
				if comment not in line[pl[0].start]:
					settings[line[pl[0]]] = line[pl[1]]
	ai = iter(ca)
	files = []
	for t in ai:
		if t.strip() == '=':
			break
		files.append(t)
	first_key = files.pop()
	first_value = None
	try:
		first_value = ai.next()
		settings[first_key] = first_value
		for p in ai:
			try:
				eq = ai.next()
			except StopIteration:
				sys.stderr.write("Missing '=' for setting %d\n" %(
						len(settings) + 1,
					)
				)
				sys.exit(1)

			if eq.strip() not in '=':
				sys.stderr.write(
					"Expecting an '=' character, but got " \
					"%r instead at parameter %d, %r.\n" %(
						eq, len(settings) + 1, p
					)
				)

			try:
				val = ai.next()
			except StopIteration:
				sys.stderr.write("Missing value for setting %d, %r\n" %(
					len(settings) + 1, p
				))
				sys.exit(1)
			settings[p] = val
	except StopIteration:
		sys.stderr.write("Missing last setting value.\n")
		sys.exit(1)

	for fp in files:
		fr = open(fp, 'r')
		try:
			lines = alter_config(settings, fr)
		finally:
			fr.close()

		if co.stdout:
			if len(files) > 1:
				sys.stderr.write(
					"WARNING: Only altering one of the given files.\n"
				)
			fp = '/dev/stdout'
		elif fp == '/dev/stdin':
			fp = '/dev/stdout'

		fw = open(fp, 'w')
		try:
			for l in lines:
				fw.write(l)
		finally:
			fw.close()
	sys.exit(0)
##
# vim: ts=3:sw=3:noet:
