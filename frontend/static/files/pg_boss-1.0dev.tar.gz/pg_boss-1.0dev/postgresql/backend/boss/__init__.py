# -*- encoding: utf-8 -*-
# $Id: __init__.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
"Backend management interfaces"
