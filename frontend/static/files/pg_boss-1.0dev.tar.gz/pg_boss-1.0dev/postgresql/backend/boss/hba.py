# -*- encoding: utf-8 -*-
# $Id: hba.py,v 1.1 2008/01/05 21:03:43 jwp Exp $
##
# Copyright 2006, PostgresPy Project.
# http://python.projects.postgresql.org
##
'PostgreSQL Host Based Authentication manipulation utilities.'
import sys
import os

comment = u'#'
separator = u' \t'

def parse_line(line, separator = separator, comment = comment):
	'parse a line from a pg_hba.conf file'
	# Filter comments and extract fields
	co = line.find(comment)
	if co == -1:
		# No comment
		hba = line.strip().split()
	else:
		hba = line[:co].strip().split()
	field_count = len(hba)
	if field_count == 0:
		return

	# Get the line slices of fields
	hba_slices = []
	consumed = 0
	for x in hba:
		xo = line.find(x)
		hba_slices.append(slice(consumed + xo, consumed + xo + len(x)))
		consumed += xo + len(x)
		line = line[xo+len(x):]
	return tuple(hba_slices)

def write_config(seq, writer):
	'A configuration writer that will trample & merely write the settings'
	for i in seq:
		writer(' '.join(i) + os.linesep)

def read_config(iter, s = None, selector = None):
	'Read and split all uncommented entries in the given iterator'
	if s is None:
		s = []
	for l in iter:
		l = l.strip()
		# A simple reader is not interested in comments.
		l = l[:l.find(comment)]
		if l:
			fields = l.split()
			if (selector is None) or selector(fields):
				s.append(tuple(fields))
	return s

class Sequence(object):
	'A sequence manipulation interface for managing PostgreSQL\'s HBA'

	def __init__(self, iterable):
		'Take a HBA line producing iterable to manipulate'
		self.lines = []
		self._laws = []
		line_num = 0
		for x in iterable:
			self.lines.append(x)
			# Ignore comments and empty lines
			if not x[:x.find(comment)].isspace():
				pl = parse_line(x)
				if pl is not None:
					self._laws.append((line_num, pl))
			line_num += 1
		if self.lines:
			self._newline = self.lines[0][-1]
			if self._newline not in '\n\r':
				self._newline = '\n'

	def insert(self, index, entry, position = 0):
		'Insert a new entry at the given index using the specified position'
		lawlen = len(self._laws)
		if position not in (-1, 0):
			raise ValueError, "invalid entry position %r" %(position,)
		if index < 0:
			index = lawlen + index
		if index >= lawlen:
			near_position = lawlen
		line_num, pl = self._laws[index + position]
		nearline = self.lines[line_num]
		newline = self._format_like(entry, nearline, pl) + self._newline
		pl = parse_line(newline)
		newline_num = (line_num + (index - (index + position)))
		self._laws.insert(index, (newline_num, pl))
		self.lines.insert(newline_num, newline)
		self._correct_indexes_past(index + 1, 1)

	def insert_before(self, fields, entry):
		self.insert(self.index(fields), entry, position = 0)

	def insert_after(self, fields, entry):
		self.insert(self.index(fields)+1, entry, position = -1)

	def append(self, entry):
		self.insert(len(self), entry, position = -1)

	def index(self, fields):
		fields = tuple(fields)
		for x in xrange(len(self._laws)):
			if self[x] == fields:
				return x
		raise ValueError, "%r not in hba list" %(fields,)

	def find(self, fields):
		fields = tuple(fields)
		for x in xrange(len(self._laws)):
			if self[x] == fields:
				return x
		return -1

	def pop(self, index = 0):
		val = self[index]
		del self[index]
		return val

	# TODO: Do real formatting so that columns are guarenteed to line up.
	# The current routine merely mimics what is found in the given line.
	def _format_like(self, fields, line, pl):
		ex_slices = [0]
		for x in pl:
			ex_slices.append(x.start)
			ex_slices.append(x.stop)
		ex_slices.append(len(line))
		formatting = [
			line[ex_slices[(x*2)]:ex_slices[(x*2)+1]]
			for x in xrange((len(ex_slices) / 2))
		]

		# Compensate for too few separations by just inserting a space.
		formatting = formatting + ((len(fields) - (len(formatting))) * [' '])

		# Catenate all the fields with the same spacing used
		# by the given pl in the line. 
		return ''.join([
			formatting[x] + fields[x]
			for x in xrange(len(fields))
		]) + line[ex_slices[-2]:ex_slices[-1]]

	def _correct_indexes_past(self, index, correction):
		'Correct the line numbers in the laws'
		if index < len(self._laws):
			for x in xrange(index, len(self._laws)):
				num, pl = self._laws[x]
				self._laws[x] = (num + correction, pl)

	def __getitem__(self, index):
		if isinstance(index, slice):
			return [
				tuple([self.lines[line_num][y] for y in pl])
				for line_num, pl in self._laws[index]
			]
		else:
			line_num, pl = self._laws[index]
			line = self.lines[line_num]
			return tuple([line[x] for x in pl])

	def __setitem__(self, index, val):
		if isinstance(index, slice):
			laws = self._laws[index]
			newlaws = []
			comments = []
			comment_index = index.start
			for newlaw, oldlaw in zip(val, laws):
				oldline = self.lines[oldlaw[0]]
				if newlaw is None:
					self.lines[oldlaw[0]] = comment + oldline
					comments.append(comment_index)
				else:
					nl = self.lines[oldlaw[0]] = self._format_like(newlaw, oldline, oldlaw[1])
					newlaw = (oldlaw[0], parse_line(nl))

				# Append the new law regardless.
				# If it's a comment it will still be deleted.
				newlaws.append(newlaw)

				# Track the comments so they can be deleted afterwards.
				comment_index += 1
			self._laws[index] = newlaws

			# Delete commented lines from the top down.
			comments.reverse()
			for x in comments:
				del self._laws[x]
		else:
			line_num, pl = self._laws[index]
			line = self.lines[line_num]
			if val is None:
				self.lines[line_num] = comment + line
				del self._laws[index]
			else:
				newline = self._format_like(val, line, pl)
				self.lines[line_num] = newline
				self._laws[index] = (line_num, parse_line(newline))

	def __delitem__(self, index):
		if isinstance(index, slice):
			laws = self._laws[index]
			del self._laws[index]
			# Delete the lines starting with the last to ensure.
			lines = [x[0] for x in laws]
			lines.sort(reverse = True)
			for x in lines:
				del self.lines[x]
			self._correct_indexes_past(index.start, (- len(laws)))
		else:
			line_num, pl = self._laws[index]
			del self.lines[line_num]
			self._correct_indexes_past(index, -1)
			del self._laws[index]

	def __len__(self):
		return len(self._laws)

	def writeto(self, writer):
		for x in self.lines:
			writer(x)

def main(args):
	from optparse import OptionParser
	op = OptionParser(
		"%prog [--stdout] [-f settings] config_file " \
		"place|update|delete|comment\n\n" \
		"%prog config_file place 'local all pgsql trust' before " \
		"'local all all reject'\n" \
		"%prog config_file place 'local all pgsql trust' after 2\n" \
		"%prog config_file update 'local all all trust' to " \
		"'local all pgsql trust'\n" \
		"%prog config_file delete 'host all all 127.0.0.1/32 trust'\n"
		"%prog config_file comment 'hostssl all all 127.0.0.1/32 trust'",
		version = '0'
	)
	op.allow_interspersed_args = False
	op.add_option(
		'--stdout',
		dest = 'stdout',
		help = 'Redirect the changed file to standard output',
		action = 'store_true',
		default = False
	)
	co, ca = op.parse_args(args)
	if not ca:
		sys.exit(0)
	src_path = ca.pop(0)

	if co.stdout or src_path == '-':
		outfile = sys.stdout
	else:
		outfile = None

	if src_path == '-':
		src = sys.stdin
	else:
		src = open(src_path)

	try:
		hba = Sequence(src)
	finally:
		src.close()

	ci = iter(ca)
	for command in ci:
		command = command.lower().strip()
		# Comment/Delete x
		if command in ('d', 'del', 'delete', 'c', '#', 'comment'):
			try:
				index_id = ci.next()
			except StopIteration:
				sys.stderr.write(
					'%s requires an argument to identify the HBA entry to strike'
				)
				return 1
			try:
				try:
					index_id = int(index_id)
					if command.startswith('d'):
						del hba[index_id]
					else:
						hba[index_id] = None
				except ValueError:
					if command.startswith('d'):
						del hba[hba.index([
							x.strip() for x in index_id.split() if x.strip()
						])]
					else:
						hba[index_id] = None
			except IndexError:
				sys.stderr.write(
					'No rule at index %r exists in %r, %r indexes total.\n' %(
					index_id, src_path, len(hba)
				))
				return 1
		# Update x to y
		elif command == 'update':
			try:
				index_id = ci.next()
			except StopIteration:
				sys.stderr.write(
					"The %r command requires three arguments, given none.\n" %(
						command,
					)
				)
				return 1
			try:
				to_marker = ci.next()
			except StopIteration:
				sys.stderr.write(
					"The %r command requires a 'to' marker "
					"after the first argument.\n" %(command,)
				)
				sys.stderr.write(
					"HINT: %r %r to 'host all all 127.0.0.1/32 trust'\n" %(
						command, index_id
					)
				)
				return 1
			try:
				new_fields = ci.next()
				new_fields = [x for x in new_fields.split() if x]
			except StopIteration:
				sys.stderr.write(
					'The %r command requires three arguments, only given two.\n' %(
						command,
					)
				)
				sys.stderr.write(
					"HINT: You need to specify what to set the identified field to.\n"
				)
				return 1
			try:
				index_id = int(index_id)
			except ValueError:
				index_id = hba.find([x for x in index_id.split() if x])
				if index_id == -1:
					sys.stderr.write(
						'Rule %r not found in %r.\n' %(iid, src_path)
					)
					return 1
			hba[index_id] = new_fields
		# Place x after|before y
		elif command in ('place', 'p'):
			try:
				new_rule = ci.next()
			except StopIteration:
				sys.stderr.write(
					"%r requires three arguments, given none.\n" %(
						command,
					)
				)
				return 1
			try:
				b_or_a_marker = ci.next().lower().strip()
			except StopIteration:
				sys.stderr.write(
					"%r requires 'before' or 'after' as its second argument.\n" %(
						command,
					)
				)
				sys.stderr.write(
					"HINT: place %r before 'host all all 127.0.0.1 trust'.\n" %(
						command,
					)
				)
				return 1
			if b_or_a_marker not in ('before', 'after'):
				sys.stderr.write(
					"%r requires a 'before' or 'after' position specifier " \
					"as its second argument.\n" %(command,)
				)
				return 1
			position = b_or_a_marker == 'after' and -1 or 0

			try:
				index_id = ci.next()
			except StopIteration:
				sys.stderr.write(
					'%r requires a rule identifier that specifies what rule ' \
					'the new rule will placed next to.\n'
				)
				return 1

			try:
				index_id = int(index_id)
			except ValueError:
				iid = index_id
				index_id = hba.find([x for x in index_id.split() if x])
				if index_id == -1:
					sys.stderr.write(
						'Rule %r not found in %r.\n' %(iid, src_path)
					)
					return 1
			new_rule = [x for x in new_rule.split() if x]
			try:
				if position == -1:
					index_id += 1
				hba.insert(index_id, new_rule, position)
			except IndexError:
				sys.stderr.write(
					'%r contains %d rules, explicit index, %d, ' \
					'is out of bounds.\n' %(
						src_path, len(hba), index_id,
					)
				)
				sys.stderr.write(
					'HINT: Editor uses zero-based index addressing.\n'
				)
				return 1
		else:
			sys.stderr.write("Unknown command %r, -h for usage.\n" %(command,))
			return 1

	if outfile is None:
		outfile = open(src_path, 'w')
	try:
		hba.writeto(outfile.write)
	finally:
		outfile.close()

	return 0

if __name__ == '__main__':
	sys.exit(main(sys.argv[1:]))
##
# vim: ts=3:sw=3:noet:
