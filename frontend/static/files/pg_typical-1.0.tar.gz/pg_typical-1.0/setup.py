#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.17 2008/05/30 02:52:28 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
NAME = 'typical'
VERSION = '1.0'

LONG_DESCRIPTION = """
Typical is a project providing PostgreSQL binary type I/O routines for Python.
At the core, pstruct, it provides the transformation routine. The outer layers,
oidmap and stdio, it provides dictionaries that associate the PostgreSQL type
oid with the transformation routine.
"""

classifiers = [
	'Development Status :: 5 - Production/Stable',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' : 'PostgreSQL binary type I/O routines',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'classifiers' : classifiers,
	'zip_safe' : True,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
	'namespace_packages' : [
		'postgresql', 'postgresql.protocol'
	],
	'packages' : [
		'postgresql',
		'postgresql.protocol',
		'postgresql.protocol.typical',
	],
	'install_requires' : [
		'pg_foundation >= 1.0' 
	],
	'test_suite' : 'postgresql.protocol.typical.test',
}

# Conditionally provide pkg_documentation keys.
try:
	import pkg_resources as pr
	try:
		pr.require('jwp_pkg_documentation')
		defaults['doc_ignore'] = [
			'postgresql.protocol.typical.test',
		]
	except pr.DistributionNotFound:
		pass
except ImportError:
	pass

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
