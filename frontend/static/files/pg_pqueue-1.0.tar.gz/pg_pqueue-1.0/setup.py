#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.17 2008/05/30 02:57:15 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
## 
import sys
import os
from setuptools import Extension, find_packages

NAME = 'pqueue'
VERSION = '1.0'
PACKAGE = 'postgresql.protocol.' + NAME

LONG_DESCRIPTION = """
PQueue is a package providing low-level PQ protocol classes for interacting with
a PostgreSQL database. It supports version 3.0 of the protocol--the current
primary version of protocol. The package also provides a basic protocol
transaction class. This class keeps the state of the protocol in an interrupt
safe manner, and validates the integrity of the communication as messages are
received.

In general, you probably will never use this package directly, unless you are
writing a driver.
"""

classifiers = [
	'Development Status :: 5 - Production/Stable',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' : 'PostgreSQL PQ protocol modules',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'classifiers' : classifiers,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
	'zip_safe' : True,
	'namespace_packages' : [
		'postgresql',
		'postgresql.protocol',
	],
	'packages' : [
		'postgresql',
		'postgresql.protocol',
		PACKAGE,
	],
	'ext_modules' : [
		Extension(
			PACKAGE + '.cbuffer',
			[os.path.join('postgresql', 'protocol', NAME, 'buffer.c')],
			libraries = (sys.platform == 'win32' and ['ws2_32'] or []),
		),
	],
	'test_suite' : PACKAGE + '.test',
}

# Conditionally provide pkg_documentation keys.
try:
	import pkg_resources as pr
	try:
		pr.require('jwp_pkg_documentation')
		defaults['doc_ignore'] = [
			PACKAGE + '.test',
		]
	except pr.DistributionNotFound:
		pass
except ImportError:
	pass

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
