# -*- encoding: utf-8 -*-
# $Id: __init__.py,v 1.1 2008/01/04 21:07:57 jwp Exp $
##
# copyright 2005, pg/python project.
# http://python.projects.postgresql.org
##
'PQ protocol facilities'
