#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.27 2008/05/30 02:50:43 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
NAME = 'foundation'
VERSION = '1.0'

LONG_DESCRIPTION = """
The PostgreSQL foundation project provides data and classes that relate to core
PostgreSQL elements. Exception hierarchy, type implementations, type Oid
identification, and encoding aliases to name a few.

The Postgres foundation package provides various utilities for working
PostgreSQL:

 * PostgreSQL exception classes and SQL state codes
 * PostgreSQL types and named Oids
 * Version parser
 * pg_config dictionary converter
 * encoding aliases
 * bytea codec
 * 'optparse' options for command line client programs
 * pgpass file parser
 * environment variable collector
 * PQ IRI parser (think DSN, but in URL form)
"""

CLASSIFIERS = [
	'Development Status :: 5 - Production/Stable',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

NAMESPACE_PACKAGES = [
	'postgresql',
	'postgresql.test',
	'postgresql.encodings',
	'postgresql.utility',
]
PACKAGES = [
	'postgresql',
	'postgresql.test',
	'postgresql.encodings',
	'postgresql.utility',
	'postgresql.utility.client',
]

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' : 'PostgreSQL foundations for Python',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'zip_safe' : True,
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
	'classifiers' : CLASSIFIERS,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'namespace_packages' : NAMESPACE_PACKAGES,
	'packages' : PACKAGES,
	'test_suite' : 'postgresql.test.test_foundation',
}

# Conditionally provide pkg_documentation keys.
try:
	import pkg_resources as pr
	try:
		pr.require('jwp_pkg_documentation')
		defaults['doc_ignore'] = [
			'postgresql.test.',
			'postgresql.utility.client.test',
			# A generated dictionary that serves no purpose being included.
			'postgresql.exceptions.CodeClass',
		]
	except pr.DistributionNotFound:
		pass
except ImportError:
	pass

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
