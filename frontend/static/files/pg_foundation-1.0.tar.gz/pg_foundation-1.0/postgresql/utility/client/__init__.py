# -*- coding: utf-8 -*-
# $Id: __init__.py,v 1.4 2008/03/18 22:02:36 jwp Exp $
##
'Client utility modules'
