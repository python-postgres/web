##
# copyright 2009, James William Pye
# http://python.projects.postgresql.org
##
r"""
See: `postgresql.documentation.index`
"""
__docformat__ = 'reStructuredText'
