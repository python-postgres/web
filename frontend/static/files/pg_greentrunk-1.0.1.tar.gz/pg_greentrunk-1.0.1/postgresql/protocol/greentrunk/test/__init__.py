# -*- encoding: utf-8 -*-
##
'Green Trunk interface conformance tests space'
