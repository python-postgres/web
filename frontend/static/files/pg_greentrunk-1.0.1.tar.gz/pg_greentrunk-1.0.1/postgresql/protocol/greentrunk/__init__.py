# -*- encoding: utf-8 -*-
##
'Green Trunk interface space'

def connection_api_ep():
	"""
	Console script entry point for pg_greentrunk.
	"""
	help('postgresql.protocol.greentrunk.api')
