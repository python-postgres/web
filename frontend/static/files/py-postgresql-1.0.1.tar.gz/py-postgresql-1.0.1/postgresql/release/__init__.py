##
# copyright 2009, James William Pye
# http://python.projects.postgresql.org
##
"""
Release management code and project meta-data.
"""
