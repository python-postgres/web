#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.12 2008/05/30 02:51:29 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
import sys
import os

NAME = 'tin'
VERSION = '1.0dev'

LONG_DESCRIPTION = """
pg_tin, Test INfrastructure, is a project to provide testing facilities for
PostgreSQL applications. It is intended to automate the initialization of the
database, and provide the capacity to seemlessly manage the various
clusters and the configuration options thereof.

tin commands
------------

::

	help     Print this help menu
	list     Print paths and version information to selected clusters [ls]
	environ  Print standard PostgreSQL environment variable for connectivity [env]
	string   Print standard PostgreSQL connectivity options [str]
	path     Print path to selected clusters
	create   Create a cluster using the given pg_config
	drop     Drop the selected database clusters
	recreate Recreate the selected clusters (configuration is lost)
	stop     Signal the selected clusters to shutdown
	start    Start the selected clusters
	reload   Run pg_ctl reload on the selected clusters
	command  Run the specified command with the current cluster's environment
	set      Set the specified server parameters in each selected cluster
	show     Show the specified server parameters in each selected cluster
	readlogs Read the selected cluster's log file
	logs     Print absolute paths to the selected cluster's log file

sample invocations
------------------

::

	pg_tin create /usr/local/pgsql/bin/pg_config
	pg_tin list
	pg_tin set "search_path=public,utils" "shared_buffers=5000"
	pg_tin -V 8.2 start
	pg_tin -V 8.1 com psql -f sql
"""

classifiers = [
	'Development Status :: 4 - Beta',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' : 'PostgreSQL Test INfrastructure',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'keywords' : 'postgresql test testing unittest database',
	'classifiers' : classifiers,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'zip_safe' : True,
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
	'install_requires' : [
		'jwp_terminfo >= 1.0',
		'pg_foundation >= 1.0',
		'pg_boss >= 1.0dev',
	],
	'namespace_packages' : [
		'postgresql',
		'postgresql.backend',
	],
	'packages' : [
		'postgresql',
		'postgresql.backend',
		'postgresql.backend.tin',
	],
	'entry_points' : {
		'console_scripts' : [
			'pg_tin = postgresql.backend.tin.command:main'
		]
	},
}

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
