# -*- encoding: utf-8 -*-
# $Id: control.py,v 1.3 2008/06/22 08:47:55 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
'Cup o\' clusters interface'
import sys
import os
import warnings
from random import random

import postgresql.utility.version as pg_version
import postgresql.utility.config as pg_config
from postgresql.backend.boss.cluster import Cluster as pg_cluster

CONFIG_FILENAME = 'pg_tin.conf'
class TinError(Exception):
	pass
class UnresolvablePgConfig(TinError):
	pass

# FIXME: This should check if it can bind the port as well.
def genport(exceptions = (), limit = 100):
	port = 0
	exceptions = (port,) + tuple(exceptions)
	while port in exceptions and limit:
		limit -= 1
		# Get a random a port from 5433 to 55433
		port = int(random() * 50000) + 5433
	return port

class Cup(object):
	'The cup of clusters.'
	def __init__(self, path, parallels = 0):
		self.path = path
		if not os.path.exists(path):
			os.mkdir(path)

		clusters = []
		for x in os.listdir(path):
			clpath = os.path.join(path, x)
			cfpath = os.path.join(clpath, 'pg_config')

			# Identify a cluster by whether or not it has a pg_config link.
			if os.path.isdir(clpath) and os.path.islink(cfpath):
				c = pg_cluster(clpath, pg_config.dictionary(cfpath))
				clusters.append(c)
				c.version_type, vstr = c.config['version'].split()
				c.version_info = pg_version.one.parse(vstr)

		self.clusters = clusters

	def add(self, pg_config_path, **kw):
		# Find the highest cluster number. When a new cluster is created,
		# add one to the count to get the unique name.
		high = 0
		conf = pg_config.dictionary(pg_config_path)

		# If it's not an absolute path, try to make one.
		if not os.path.isabs(pg_config_path):
			abspath = os.path.realpath(os.path.join(conf['bindir'], 'pg_config'))
			if not os.path.exists(abspath):
				raise UnresolvablePgConfig(abspath)
		else:
			abspath = pg_config_path

		for x in os.listdir(self.path):
			try:
				x = os.path.basename(x)
				if not x.startswith('cluster_'):
					continue
				num = int(x[len('cluster_'):])
			except ValueError:
				# Likely not a formal cluster
				continue
			if num > high:
				high = num
		ddirpath = os.path.join(self.path, 'cluster_%d' %(high + 1,))

		kw['superusername'] = 'tinman'
		if not kw.has_key('logfile'):
			kw['logfile'] = sys.stderr
		clust = pg_cluster.create(ddirpath, conf, **kw)

		clust.version_type, ver = clust.config['version'].split()
		pgv = pg_version.one.parse(ver)
		clust.version_info = pgv
		config = {
			'log_min_messages' : 'info',
			'log_error_verbosity' : 'verbose',
			'silent_mode' : 'off',
			'port' : str(genport([
				int(x.get_parameters(('port',))['port']) for x in self.clusters
			])),
		}

		if pgv >= (8, 0):
			config['log_destination'] = "'stderr'"
			if pgv < (8, 3):
				config['redirect_stderr'] = 'off'
		clust.set_parameters(config)

		# init logfile and its header.
		f = file(os.path.join(clust.control.data, 'log'), 'w')
		f.write("%s [%s]\n[%s]\n\n" %(
			clust.control.data,
			clust.config['version'],
			clust.config['configure']
		))

		os.symlink(abspath, os.path.join(ddirpath, 'pg_config'))
		self.clusters.append(clust)
		return clust
##
# vim: ts=3:sw=3:noet:
