# -*- encoding: utf-8 -*-
# $Id: __init__.py,v 1.1 2008/01/06 06:04:55 jwp Exp $
##
'Test infrastructure space'
