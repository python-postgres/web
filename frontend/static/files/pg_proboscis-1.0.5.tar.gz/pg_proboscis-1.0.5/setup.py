#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# $Id: setup.py,v 1.27.2.6 2009/02/02 22:31:34 jwp Exp $
##
# copyright 2006, pg/python project.
# http://python.projects.postgresql.org
##
import os.path
NAME = 'proboscis'
VERSION = '1.0.5'

classifiers = [
	'Development Status :: 5 - Production/Stable',
	'Intended Audience :: Developers',
	'License :: OSI Approved :: BSD License',
	'License :: OSI Approved :: MIT License',
	'License :: OSI Approved :: Attribution Assurance License',
	'License :: OSI Approved :: Python Software Foundation License',
	'Natural Language :: English',
	'Operating System :: OS Independent',
	'Programming Language :: Python',
	'Topic :: Database',
]

LONG_DESCRIPTION = """
pg_proboscis is a pg_pqueue based driver for PostgreSQL. It provides a GreenTrunk and
a DB-API 2.0 interface to PostgreSQL databases.

contents
--------

* ``postgresql.interface.proboscis.tracenull``
* ``postgresql.interface.proboscis.greentrunk``
* ``postgresql.interface.proboscis.dbapi2``
* ``postgresql.interface.proboscis.python``
* ``pb_python`` (console script for postgresql.interface.proboscis.python)

examples
--------

Run a console with a connection::

 $ pb_python -h localhost -U pgsql -d postgres
 Python 2.5.1 (r251:54863, Dec  8 2007, 09:22:18) 
 [GCC 4.0.1 (Apple Inc. build 5465)] on darwin
 Type "help", "copyright", "credits" or "license" for more information.
 (SavingConsole)
 >>> gtx
 <postgresql.interface.proboscis.tracenull.GreenTrunk_Connection[pq://pgsql@localhost:5432/postgres] T.0>
 >>>

Make a GreenTrunk connection manually::

 >>> import postgresql.interface.proboscis.greentrunk as gt
 >>> con = gt.connector(user = 'pgsql', host = 'localhost', port = 5432, database = 'postgres')
 >>> c=con()

Make a DB-API 2.0 connection manually::

 >>> import postgresql.interface.proboscis.dbapi2 as db
 >>> c=db.connect(user = 'pgsql', host = 'localhost', port = 5432, database = 'postgres')

Notably, DSN strings are *not* directly supported. However, if you want connection
strings, the ``postgresql.utility.client.iri`` module has means for parsing PQ
IRIs and the ``postgresql.utility.client.dsn`` module has means for parsing DSNs.
"""

# No crypt? Get fcrypt.
try:
	import crypt
	del crypt
	fcrypt = []
except ImportError:
	fcrypt = ['fcrypt']

defaults = {
	'name' : 'pg_' + NAME,
	'version' : VERSION,
	'description' :
		'pg_pqueue based GreenTrunk (API) and ' \
		'DB-API 2.0 implementation for PostgreSQL',
	'long_description' : LONG_DESCRIPTION,
	'author' : 'James William Pye',
	'author_email' : 'x@jwp.name',
	'maintainer' : 'pg/python project',
	'maintainer_email' : 'python-general@pgfoundry.org',
	'url' : 'http://python.projects.postgresql.org',
	'classifiers' : classifiers,
	'download_url' : 'http://python.projects.postgresql.org/files/',
	'zip_safe' : True,
	'dependency_links' : [
		'http://python.projects.postgresql.org/files/'
	],
 
	'install_requires' : [
		'jwp_terminfo >= 1.0',
		'jwp_python_command >= 1.1',
		'pg_foundation >= 1.0',
		'pg_greentrunk >= 1.0',
		'pg_pqueue >= 1.0',
		'pg_typical >= 1.0',
		'pytz',
		# disable this requirement as easy_install will fail on it.
		#'ssl',
	] + fcrypt,

	'namespace_packages' : [
		'postgresql',
		'postgresql.interface'
	],
	'packages' : [
		'postgresql',
		'postgresql.interface',
		'postgresql.interface.proboscis',
	],
	'entry_points' : {
		'console_scripts' : [
			'pb_python = postgresql.interface.proboscis.python:main',
		]
	}
}

# Conditionally provide pkg_documentation keys.
try:
	import pkg_resources as pr
	try:
		pr.require('jwp_pkg_documentation')
		defaults['doc_ignore'] = [
			'postgresql.interface.proboscis.test.',
		]
		defaults['chapters'] = [
			'doc/changes.txt',
			'doc/connecting.txt',
			'doc/pb_python.txt',
		]
	except pr.DistributionNotFound:
		pass
except ImportError:
	pass

if __name__ == '__main__':
	from setuptools import setup
	setup(**defaults)
