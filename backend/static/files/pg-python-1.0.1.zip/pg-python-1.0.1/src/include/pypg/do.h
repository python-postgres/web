#ifndef PyPg_do_H
#define PyPg_do_H 0
#ifdef __cplusplus
extern "C" {
#endif

Datum pl_inline(PG_FUNCTION_ARGS);

#ifdef __cplusplus
}
#endif
#endif /* !PyPg_do_H */
